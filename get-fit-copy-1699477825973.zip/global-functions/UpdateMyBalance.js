import React from 'react';

const UpdateMyBalance = (myBalance, topUpValue) => {
  return myBalance + topUpValue;
};

export default UpdateMyBalance;
