import React from 'react';

const IncreaseTopUpValue = topUpValue => {
  return topUpValue + 1;
};

export default IncreaseTopUpValue;
