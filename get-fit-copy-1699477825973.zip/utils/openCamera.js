import { Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { getMimeTypeFromFilename } from '@shopify/mime-types';

async function openCamera({
  mediaTypes = ImagePicker.MediaTypeOptions.Images,
  allowsEditing = false,
  cameraType = 'back',
  videoMaxDuration,
  quality = 1,
}) {
  if (Platform.OS !== 'web') {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();

    if (status !== 'granted') {
      alert('Sorry, we need camera permissions to make this work!');
    }
  }

  let result = await ImagePicker.launchCameraAsync({
    mediaTypes,
    allowsEditing,
    cameraType,
    videoMaxDuration,
    quality,
    base64: true,
  });

  let asset = result.assets?.length > 0 ? result.assets[0] : null;

  if (!result.canceled && asset) {
    if (Platform.OS === 'web') return asset.uri;

    const mimeType = getMimeTypeFromFilename(asset.uri);

    if (asset.type === 'video') {
      const base64Video = await FileSystem.readAsStringAsync(asset.uri, {
        encoding: 'base64',
      });

      return 'data:' + mimeType + ';base64,' + base64Video;
    }

    return 'data:' + mimeType + ';base64,' + asset.base64;
  }
}

export default openCamera;
